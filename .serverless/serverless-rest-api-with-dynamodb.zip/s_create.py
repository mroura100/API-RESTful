import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='mroura10',
    application_name='api-restful-todo',
    app_uid='7W0XT4VNVQHDm7pNkL',
    org_uid='rzghmm1ndhhnYPGcxR',
    deployment_uid='8d8d3db9-3f01-437c-b7a7-2d63bf674ddd',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.4.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-dev-create', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/create.create')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
